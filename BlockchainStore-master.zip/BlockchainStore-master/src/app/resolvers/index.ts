export * from './data';
import { DataResolver } from './data';

const APP_RESOLVERS: any[] = [
    DataResolver
];
export {
    // DataResolver,
    APP_RESOLVERS
};
