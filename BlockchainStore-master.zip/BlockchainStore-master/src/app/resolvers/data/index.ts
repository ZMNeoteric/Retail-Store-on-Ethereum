export { DataResolver } from './data.resolver';
