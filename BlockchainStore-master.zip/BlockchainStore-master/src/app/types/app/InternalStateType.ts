export type InternalStateType = {
  [key: string]: any
};
