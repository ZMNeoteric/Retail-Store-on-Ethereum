import { Bcs, JQuery } from 'app/interfaces';

type WidgetProviderType = Bcs | JQuery;

export {
  WidgetProviderType
}
