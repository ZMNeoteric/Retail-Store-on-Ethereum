import { AuthGuard } from './auth.guard';

const AUTH_PROVIDERS: any[] = [
                                AuthGuard
                            ];

export {
    // AuthGuard,
    AUTH_PROVIDERS
};
