// speed up the initial styles loading
// import 'assets/styles/default/initial.scss';
const data: any = [];

export {
    data
};
