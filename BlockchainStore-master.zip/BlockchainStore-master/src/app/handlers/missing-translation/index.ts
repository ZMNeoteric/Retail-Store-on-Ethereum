export { BcsMissingTranslationHandler } from './missing-translation.handler';
