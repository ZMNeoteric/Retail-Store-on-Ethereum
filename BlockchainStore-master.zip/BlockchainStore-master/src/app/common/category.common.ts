export const CATEGORY: string = 'BlockchainStore';
