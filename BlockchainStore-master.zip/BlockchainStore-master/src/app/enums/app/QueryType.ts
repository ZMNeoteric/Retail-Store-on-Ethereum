export enum QueryType {
  Unknown = 0,
  Users,
  StoreStatistics
}
