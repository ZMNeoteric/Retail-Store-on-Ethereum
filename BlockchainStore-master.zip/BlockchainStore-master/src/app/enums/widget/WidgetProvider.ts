export enum WidgetProvider {
    Unknown,
    Bcs,
    JQuery
}
