export enum ComponentType {
    Unknown = 0,
    HelpComponent
}
