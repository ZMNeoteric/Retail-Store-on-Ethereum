export enum ActionType {
    Unknown,
    HelpOpened,
    HelpClosed
}
