export { AppPipesModule } from './app-pipes.module';
