import { NgModule } from '@angular/core';
import { APP_PIPES } from 'app/base';

@NgModule({
  imports: [],
  exports: [],
  declarations: [
    ...APP_PIPES
  ],
  providers: [

  ],
})
export class AppPipesModule { }
