export interface IStylableElement {
    id: string;
    type: string;
    style: any;
}
