import { IStylableElement } from './IStylableElement';
export interface IStylableElementMap {
     name: string;
     element: IStylableElement;
}
