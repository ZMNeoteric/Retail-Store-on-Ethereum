export interface IStyleConfigItem {
    path?: string;
    block?: string[] | string;
}
