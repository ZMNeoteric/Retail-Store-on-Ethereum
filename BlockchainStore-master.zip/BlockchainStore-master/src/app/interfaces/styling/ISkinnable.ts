import { IStyleConfig } from './IStyleConfig';

export interface ISkinnable {
    getStyleConfig(): IStyleConfig;
}
