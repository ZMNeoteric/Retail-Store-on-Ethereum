export interface ITranslation {
  Key: string;
  Content: string;
  Type: string;
  Language: string;
}
