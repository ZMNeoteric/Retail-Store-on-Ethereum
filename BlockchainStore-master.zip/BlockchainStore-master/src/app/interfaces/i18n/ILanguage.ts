// BlockchainStore language interface
export interface ILanguage {
  code: string;
  language: string;
  title: string;
}
