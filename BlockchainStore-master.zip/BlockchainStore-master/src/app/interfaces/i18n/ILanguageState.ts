export interface ILanguageState {
  code: string;
}
