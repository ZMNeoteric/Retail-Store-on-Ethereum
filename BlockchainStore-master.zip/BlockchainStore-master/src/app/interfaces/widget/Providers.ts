export interface Bcs {
  name: 'bcs';
}

export interface JQuery {
  name: 'jquery';
}
