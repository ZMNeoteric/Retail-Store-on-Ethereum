export interface IWidgetConfig {
    id: string;
    elementId?: any;
    name?: string;
    description?: string;
    content: any;
};
