export { IWidgetConfig } from './IWidgetConfig';
export { IWidgetDescriptor } from './IWidgetDescriptor';
export { IWidget } from './IWidget';
export { Bcs, JQuery } from './Providers';
