import { APP_RESOLVERS } from 'app/resolvers';
// an array of services to resolve routes with data
export const APP_RESOLVER_PROVIDERS = [
  ...APP_RESOLVERS
];
