const APP_PIPES = [

];

export {
    APP_PIPES
};
