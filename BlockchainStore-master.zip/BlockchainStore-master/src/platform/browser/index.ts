export * from './pipes';
export * from './providers';
export * from './requests';

import { PROVIDERS } from './providers';

export const BROWSER_PROVIDERS = [
  ...PROVIDERS
];
