export { BcsProfilePicturePipe } from './profile-picture.pipe';
