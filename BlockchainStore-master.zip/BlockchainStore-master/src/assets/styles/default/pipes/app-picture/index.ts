export { BcsAppPicturePipe } from './app-picture.pipe';
