export { ThemeSupport } from './theme-support.directive';
