Just send a PR!

Thanks! :smile:
